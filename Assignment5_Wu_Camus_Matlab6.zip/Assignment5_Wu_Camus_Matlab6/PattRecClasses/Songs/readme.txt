This zip archive contains four files:
melody_1.wav
melody_2.wav
melody_3.wav
readme.txt (this file)

The audio/humming performances in the three wav files (embarrassing as they may be) are all (C) Gustav Eje Henter 2012, as is this file. The entire contents of this zip archive is made available under the Attribution-NonCommercial-ShareAlike 3.0 Unported license, as specified at URL "http://creativecommons.org/licenses/by-nc-sa/3.0/".
