Information about our project presentation
------------------------------------------
Project slides : Final_Presentation_Wu_Camus_Matlab_6.pptx

demo file:  
PattRecClasses/demo.m

training and verifying file: 
PattRecClasses/final_projevct_live.mlx

Training data and testing data repertories:
PattRecClasses/Training_database/
PattRecClasses/Test_database/