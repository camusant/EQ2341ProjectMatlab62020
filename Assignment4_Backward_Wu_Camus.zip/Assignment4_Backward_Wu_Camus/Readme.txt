Assignment 4 Wu Camus - Backward algorithm

--------------------------------------------

All the changed codes are in the repertory "Changed_Code"
Names:
"@MarkovChain/backward.m"
"testBackward.m"