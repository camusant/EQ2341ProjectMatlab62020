Asssignment2_Wu_Camus
-------------------------
In this repertory, you will find our report in pdf and our codes "k_means_extract", for the k-means feature extraction,
and "filetest", for the tests.

Please put the command "addpath('GetMusicFeatures\')" in the matlab interactive menu before running "filetest"