Assignment 3 Wu Camus - Forward algorithm

--------------------------------------------

Modified files --- SEE "Changed_code" REPERTORY PLEASE
"@MarkovChain/forward.m"
"@HMM/logprob"

Test file
"testForward.m" 
with the test for the forward and for the logprob
In finite then infinite duration 