Assignment 3 Wu Camus - Forward algorithm

--------------------------------------------

Modified files
@MarkovChain/forward.m
@HMM/logprob

Test file
testForward.m